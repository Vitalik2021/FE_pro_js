// // Task 1
// alert("Hello")
// const userName = prompt("What is your name?", "")
// alert("Nice to meet you!" + " " + userName)
// // Task 2
// const user = prompt("How old are you?", "")
// alert(2022 - user)
// const name = "dfdfdfdf"
// console.log(Number("jfhjdhf"))
// const nullTob = 42 - "55"
// console.log(nullTob)

// Task 3
const userWriteAFirstNumber = +prompt("Write your Number First Number", "")
const userWriteASecondNumber = +prompt("Write your Number Second Number", "")
const sum = userWriteAFirstNumber + userWriteASecondNumber
const diff = userWriteAFirstNumber - userWriteASecondNumber
const mult = userWriteAFirstNumber * userWriteASecondNumber
const div = userWriteAFirstNumber / userWriteASecondNumber
alert(sum)
alert(diff)
alert(mult)
alert(div)

console.log(sum)
console.log(diff)
console.log(mult)
console.log(div)
